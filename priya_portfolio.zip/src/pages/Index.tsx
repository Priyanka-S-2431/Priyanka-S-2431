import React from 'react';
const Index = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <h1 className="text-4xl font-bold">Priya Selvaraj Portfolio Coming Soon</h1>
    </div>
  );
};
export default Index;